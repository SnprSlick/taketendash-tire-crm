const odbc = require('odbc');
const fs = require('fs');

// --- CONFIGURATION ---
const DSN_NAME = 'TireMaster'; // The ODBC DSN name on the source machine
const USER = 'dba';            // Default SQL Anywhere user (update if different)
const PASSWORD = 'sql';        // Default SQL Anywhere password (update if different)
const START_DATE = '2025-11-01'; // Limit scope as requested

// ⚠️ UPDATE THESE TABLE NAMES FROM YOUR PDF ⚠️
const TABLES = {
  INVOICE_HEADER: 'Invoice',      // e.g., 'wo_header', 'invoice', 'history_header'
  INVOICE_DETAIL: 'InvoiceDetail', // e.g., 'wo_detail', 'invoice_line'
  CUSTOMER: 'Customer',           // e.g., 'cust', 'customer'
  INVENTORY: 'Inventory'          // e.g., 'inv', 'product'
};

const CONNECTION_STRING = `DSN=${DSN_NAME};UID=${USER};PWD=${PASSWORD}`;

async function main() {
  let connection;

  try {
    console.log(`🔌 Connecting to ODBC DSN: ${DSN_NAME}...`);
    connection = await odbc.connect(CONNECTION_STRING);
    console.log('✅ Connected!');

    // 1. List Tables (Helper to verify names if PDF is unclear)
    console.log('\n📋 Fetching First 20 Tables (for verification)...');
    try {
      const tables = await connection.query(`
        SELECT table_name FROM sys.systable WHERE table_type = 'BASE' ORDER BY table_name TOP 20
      `);
      console.table(tables);
    } catch (e) {
      console.log('⚠️ Could not list tables (permissions or system table difference).');
    }

    // 2. Test Query: Invoices
    console.log(`\n🔍 Fetching Invoices since ${START_DATE}...`);
    const invoiceQuery = `
      SELECT TOP 10 * 
      FROM ${TABLES.INVOICE_HEADER} 
      WHERE InvoiceDate >= '${START_DATE}'
    `;
    
    console.log(`   Executing: ${invoiceQuery}`);
    const invoices = await connection.query(invoiceQuery);
    
    console.log(`✅ Found ${invoices.length} invoices.`);
    if (invoices.length > 0) {
      console.log('   Sample Invoice:', invoices[0]);
      
      // Save to JSON for inspection
      fs.writeFileSync('sample_invoices.json', JSON.stringify(invoices, null, 2));
      console.log('   💾 Saved sample to sample_invoices.json');
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.message.includes('IM002')) {
      console.error('   Hint: DSN not found. Check ODBC Administrator (32-bit vs 64-bit).');
    } else if (error.message.includes('Table or view not found')) {
      console.error('   Hint: The table name in TABLES config is incorrect. Check your PDF.');
    }
  } finally {
    if (connection) {
      await connection.close();
      console.log('\n🔌 Connection closed.');
    }
  }
}

main();
