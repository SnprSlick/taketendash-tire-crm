/*::
type SSF_write_num = {(type:string, fmt:string, val:number):string};
*/
