# Databases

This demo has been split up for clarity:

- <https://docs.sheetjs.com/docs/demos/database> covers SQL and
  structured data (including CRUD operations)

- https://docs.sheetjs.com/docs/demos/nosql covers unstructured
  data including "NoSQL" data stores.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
